﻿using System;
using System.Collections.Generic;

using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.ComponentModel;
using B4B.Portable.Models;
using System.Collections.ObjectModel;
using B4B.Portable.Services;
using System.Windows.Input;
using B4B.Portable.Commands;

namespace B4B.Portable.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged
    {
        public MainViewModel()
        {
            LoadData();
        }

        #region Ch9RSS (Ch9Rss)
        private Ch9Rss _ch9Rss = new Ch9Rss();
        public Ch9Rss Ch9RSS
        {
            get { return _ch9Rss; }
            set
            {
                _ch9Rss = value;
                NotifyPropertyChanged("Ch9RSS");
            }
        }
        #endregion

        #region Ch9Items (ObservableCollection<Ch9Item>)
        private ObservableCollection<Ch9Item> _ch9Items = new ObservableCollection<Ch9Item>();
        public ObservableCollection<Ch9Item> Ch9Items
        {
            get { return _ch9Items; }
            set
            {
                _ch9Items = value;
                NotifyPropertyChanged("Ch9Items");
            }
        }
        #endregion


        /// <summary>
        /// Creates and adds a few ItemViewModel objects into the Items collection.
        /// </summary>
        public void LoadData()
        {
            Ch9RSS = Ch9RssService.GetFakeShows();

            foreach (Ch9Item item in Ch9RSS.channel.items)
            {
                Ch9Items.Add(item);
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void NotifyPropertyChanged(String propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (null != handler)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
