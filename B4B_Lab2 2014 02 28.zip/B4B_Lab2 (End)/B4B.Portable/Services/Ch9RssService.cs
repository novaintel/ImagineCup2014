﻿using B4B.Portable.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using System.IO;
using System.Xml.Serialization;
using System.Diagnostics;
using System.Xml;


namespace B4B.Portable.Services
{
    public class Ch9RssService
    {

        public static Ch9Rss GetFakeShows()
        {
            Ch9Rss returnFeed = new Ch9Rss();
            returnFeed.version = "2.0";
            returnFeed.channel = new Ch9Channel();
            returnFeed.channel.description = "Channel 9 Sample Description";
            returnFeed.channel.link = "http://channel9.msdn.com/";
            returnFeed.channel.title = "Channel 9";

            returnFeed.channel.items.Add(new Ch9Item() { title = "runtime one", description = "Maecenas praesent accumsan bibendum", comments = "Facilisi faucibus habitant inceptos interdum lobortis nascetur pharetra placerat pulvinar sagittis senectus sociosqu" });
            returnFeed.channel.items.Add(new Ch9Item() { title = "runtime two", description = "Dictumst eleifend facilisi faucibus", comments = "Suscipit torquent ultrices vehicula volutpat maecenas praesent accumsan bibendum dictumst eleifend facilisi faucibus" });
            returnFeed.channel.items.Add(new Ch9Item() { title = "runtime three", description = "Habitant inceptos interdum lobortis", comments = "Habitant inceptos interdum lobortis nascetur pharetra placerat pulvinar sagittis senectus sociosqu suscipit torquent" });
            returnFeed.channel.items.Add(new Ch9Item() { title = "runtime four", description = "Nascetur pharetra placerat pulvinar", comments = "Ultrices vehicula volutpat maecenas praesent accumsan bibendum dictumst eleifend facilisi faucibus habitant inceptos" });
            returnFeed.channel.items.Add(new Ch9Item() { title = "runtime five", description = "Maecenas praesent accumsan bibendum", comments = "Maecenas praesent accumsan bibendum dictumst eleifend facilisi faucibus habitant inceptos interdum lobortis nascetur" });
            returnFeed.channel.items.Add(new Ch9Item() { title = "runtime six", description = "Dictumst eleifend facilisi faucibus", comments = "Pharetra placerat pulvinar sagittis senectus sociosqu suscipit torquent ultrices vehicula volutpat maecenas praesent" });
            returnFeed.channel.items.Add(new Ch9Item() { title = "runtime seven", description = "Habitant inceptos interdum lobortis", comments = "Accumsan bibendum dictumst eleifend facilisi faucibus habitant inceptos interdum lobortis nascetur pharetra placerat" });
            returnFeed.channel.items.Add(new Ch9Item() { title = "runtime eight", description = "Nascetur pharetra placerat pulvinar", comments = "Pulvinar sagittis senectus sociosqu suscipit torquent ultrices vehicula volutpat maecenas praesent accumsan bibendum" });
            returnFeed.channel.items.Add(new Ch9Item() { title = "runtime nine", description = "Maecenas praesent accumsan bibendum", comments = "Facilisi faucibus habitant inceptos interdum lobortis nascetur pharetra placerat pulvinar sagittis senectus sociosqu" });
            returnFeed.channel.items.Add(new Ch9Item() { title = "runtime ten", description = "Dictumst eleifend facilisi faucibus", comments = "Suscipit torquent ultrices vehicula volutpat maecenas praesent accumsan bibendum dictumst eleifend facilisi faucibus" });
            returnFeed.channel.items.Add(new Ch9Item() { title = "runtime eleven", description = "Habitant inceptos interdum lobortis", comments = "Habitant inceptos interdum lobortis nascetur pharetra placerat pulvinar sagittis senectus sociosqu suscipit torquent" });
            returnFeed.channel.items.Add(new Ch9Item() { title = "runtime twelve", description = "Nascetur pharetra placerat pulvinar", comments = "Ultrices vehicula volutpat maecenas praesent accumsan bibendum dictumst eleifend facilisi faucibus habitant inceptos" });
            returnFeed.channel.items.Add(new Ch9Item() { title = "runtime thirteen", description = "Maecenas praesent accumsan bibendum", comments = "Maecenas praesent accumsan bibendum dictumst eleifend facilisi faucibus habitant inceptos interdum lobortis nascetur" });
            returnFeed.channel.items.Add(new Ch9Item() { title = "runtime fourteen", description = "Dictumst eleifend facilisi faucibus", comments = "Pharetra placerat pulvinar sagittis senectus sociosqu suscipit torquent ultrices vehicula volutpat maecenas praesent" });
            returnFeed.channel.items.Add(new Ch9Item() { title = "runtime fifteen", description = "Habitant inceptos interdum lobortis", comments = "Accumsan bibendum dictumst eleifend facilisi faucibus habitant inceptos interdum lobortis nascetur pharetra placerat" });
            returnFeed.channel.items.Add(new Ch9Item() { title = "runtime sixteen", description = "Nascetur pharetra placerat pulvinar", comments= "Pulvinar sagittis senectus sociosqu suscipit torquent ultrices vehicula volutpat maecenas praesent accumsan bibendum" });
        
            return returnFeed;
        }

        public static async Task<Ch9Rss> GetShows()
        {
            var httpClient = new HttpClient();

            try
            {
                string response = await httpClient.GetStringAsync("http://channel9.msdn.com/Feeds/RSS");
                StringReader stringRead = new StringReader(response);
                XmlSerializer xmlS = new XmlSerializer(typeof(Ch9Rss));
                XmlReader reader = XmlReader.Create(stringRead);
                Ch9Rss result = (Ch9Rss)xmlS.Deserialize(reader);
                return result;

            }
            catch (Exception e)
            {
                Debug.WriteLine(e.Message);
                return null;
            }
        }

    }
}
