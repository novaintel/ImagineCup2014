﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace B4B.Portable.Models
{

    // This set of classes help to define the XML
    //   structure in the Channel9 RSS feed in such
    //   a way that the XMLSerializer can manage it

    [XmlRoot("rss")]
    public class Ch9Rss
    {
        [XmlAttribute]
        public string version = "2.0";
        public Ch9Channel channel = new Ch9Channel();
    }

    [XmlRoot("channel")]
    public class Ch9Channel
    {
        public string title;
        public string link;
        public string description;
        [XmlElement("item")]
        public List<Ch9Item> items = new List<Ch9Item>();
    }
    public class Ch9Item
    {
        // We will be binding to the Ch9Item, so it needs
        //   to be built for binding 

        #region title Property (string)
        private string _title;
        public string title
        {
            get { return _title; }
            set { _title = value; }
        }
        #endregion

        #region link Property (string)
        private string _link;
        public string link
        {
            get { return _link; }
            set { _link = value; }
        }
        #endregion

        #region guid Property (string)
        private string _guid;
        public string guid
        {
            get { return _guid; }
            set { _guid = value; }
        }
        #endregion

        #region description Property (string)
        private string _description;
        public string description
        {
            get { return _description; }
            set { _description = value; }
        }
        #endregion

        #region comments Property (string)
        private string _comments;
        public string comments
        {
            get { return _comments; }
            set { _comments = value; }
        }
        #endregion

        #region thumbnail Property (List<ThumbNail>)
        private List<Thumbnail> _thumbnail;
        [XmlElement(Namespace = "http://search.yahoo.com/mrss/")]
        public List<Thumbnail> thumbnail
        {
            get { return _thumbnail; }
            set { _thumbnail = value; }
        }
        #endregion

        #region group Property (Group)
        private Group _group;
        [XmlElement(Namespace = "http://search.yahoo.com/mrss/")]
        public Group group
        {
            get { return _group; }
            set { _group = value; }
        }
        #endregion

        #region tags Property (new List<string>())
        private List<string> _tags = new List<string>();
        [XmlElement("category")]
        public List<string> tags
        {
            get { return _tags; }
            set { _tags = value; }
        }
        #endregion

    }

    [XmlRoot(Namespace = "http://search.yahoo.com/mrss/")]
    public class Thumbnail
    {
        #region url Property (string)
        private string _url;
        [XmlAttribute]
        public string url
        {
            get {return _url;}
            set {_url = value;}
        }
        #endregion

        #region height Property (string)
        private string _height;
        [XmlAttribute]
        public string height
        {
            get {return _height;}
            set {_height = value;}
        }
        #endregion

        #region width Property (string)
        private string _width;
        [XmlAttribute]
        public string width
        {
            get {return _width;}
            set {_width = value;}
        }
        #endregion
    }

    [XmlRoot(Namespace = "http://search.yahoo.com/mrss/")]
    public class Group
    {
        #region content Property (List<Content>)
        private List<Content> _content = new List<Content>();
        [XmlElement(Namespace = "http://search.yahoo.com/mrss/")]
        public List<Content> content
        {
            get { return _content; }
            set { _content = value; }
        }
        #endregion
    }

    [XmlRoot(Namespace = "http://search.yahoo.com/mrss/")]
    public class Content
    {
        #region url Property (string)
        private string _url;
        [XmlAttribute]
        public string url
        {
            get {return _url;}
            set {_url = value;}
        }
        #endregion

        #region expression Property (string)
        private string _expression;
        [XmlAttribute]
        public string expression
        {
            get {return _expression;}
            set {_expression = value;}
        }
        #endregion

        #region duration Property (string)
        private string _duration;
        [XmlAttribute]
        public string duration
        {
            get {return _duration;}
            set {_duration = value;}
        }
        #endregion

        #region fileSize Property (string)
        private string _fileSize;
        [XmlAttribute]
        public string fileSize
        {
            get {return _fileSize;}
            set {_fileSize = value;}
        }
        #endregion

        #region type Property (string)
        private string _type;
        [XmlAttribute]
        public string type
        {
            get {return _type;}
            set {_type = value;}
        }
        #endregion

        #region medium Property (string)
        private string _medium;
        [XmlAttribute]
        public string medium
        {
            get {return _medium;}
            set {_medium = value;}
        }
        #endregion

    }
}
